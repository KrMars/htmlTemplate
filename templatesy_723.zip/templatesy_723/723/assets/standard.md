### 开发环境

-   OS：Windows
-   编辑器：Atom
-   cmd：Cmder

### Atom 插件

-   [atom-beautify](https://atom.io/packages/atom-beautify)

    #### Less

    -   [x] Beautify On Save

    #### Javascript

    -   [ ] Disable Beautifying Language

    #### Markdown

    -   [x] Beautify On Save
    -   [x] Default Beautifier:Remark

    #### HTML

    -   [x] Beautify On Save

-   [linter](https://atom.io/packages/linter)
    -   [ ] Lint on Change
-   [linter-eslint](https://atom.io/packages/linter-eslint)
    -   [x] Fix errors on save

### Cmder 主题

-   [Panda-Theme-Cmder](https://github.com/HamidFaraji/Panda-Theme-Cmder)
